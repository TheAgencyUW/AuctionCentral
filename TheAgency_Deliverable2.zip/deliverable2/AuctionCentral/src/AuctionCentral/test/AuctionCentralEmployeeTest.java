/*
 * JUnit testing for the ACE
 * 
 * AuctionCentralEmployeeTest.java
 */

package AuctionCentral;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import AuctionCentral.AuctionCentralEmployee;
import AuctionCentral.Calendar;

/**
 * Testing the ACE class
 * 
 * @author Phil
 *
 */
public class AuctionCentralEmployeeTest 
{

	//setting up
	private AuctionCentralEmployee ace;
	private Calendar calendar;
	
	/**
	 * Setting up for the test
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception 
	{
		calendar = new Calendar();
		ace = new AuctionCentralEmployee(calendar);
	}

	/**
	 * Testing if the ACE was created
	 */
	@Test
	public void testAuctionCentralEmployee() 
	{
		fail("Not yet implemented");
	}
	
	
	/**
	 * Testing if the monthly calendar was shown. 
	 * 
	 * May or may not need this test. 
	 */
	@Test
	public void testViewMonthlyCalendar() 
	{
		fail("Not yet implemented");
	}

}
