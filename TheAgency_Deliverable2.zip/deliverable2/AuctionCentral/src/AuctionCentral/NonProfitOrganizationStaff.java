package AuctionCentral;

/**
 * 
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 * @author Indiana, Tan Pham
 * Last edit by Tan Pham
 * Sets up the Non-Profit view of the Auction Central Project.
 */
public class NonProfitOrganizationStaff {


	/**
	 * Holds the calendar for use by ACE.
	 */
	private Calendar myCalendar;

	/**
	 * Holds the name for the employee.
	 */
	private String staffName;

	private String myOrganizationName;

	/**
	 * Gets input from the user.
	 */
	private static Scanner myIn;

	/** A printstream for a shortcut to print out to the console.*/
	private static PrintStream myOut ;
	/**
	 * Holds the current acution for this non-profit.
	 */
	private Auction currentAuction;

	/**
	 * Constructor.
	 */
	public NonProfitOrganizationStaff(Calendar calendar, String name) {
		myCalendar = calendar;
		staffName = name;
		loadStaff();
		myOut = new PrintStream(System.out, true);
		myIn = new Scanner(System.in);
	}

	public void staffInterface(){
		String input;
		boolean back = false;
		while(!back){
			myOut.println("Welcome " + staffName);
			myOut.println("Please enter a command:\n0:log out\n1: add new auction.\n"
					+ "2: view the current auction.\n");
			input = myIn.next();
			if(input.equals("0")){	//break the while loop, end NPO_Interface(), return control back to main class.
				back = true;
			}else if(input.equals("1")){
				addNewAuction();
			}else if(input.equals("2")){
				viewCurrentAuction();
			}else{
				myOut.println("Invalid input");
			}
		}

	}

	private void loadStaff(){
		String date = "";
		try {
			myIn = new Scanner(new File(staffName + ".txt"));			
			myOrganizationName = myIn.next();
			if(myIn.hasNext()) date = myIn.next();
			myIn.close();
		} catch (FileNotFoundException e) {
			myOut.println("staff not found, login as new staff");
		}
		for(int i = 0; i < myCalendar.getMyCurrentAuctions().size(); i++){
			if(myCalendar.getMyCurrentAuctions().get(i).getName().equals(myOrganizationName + " - " + date)){
				currentAuction = myCalendar.getMyCurrentAuctions().get(i);
			}
		}

	}

	/**
	 * Adds a new auction to the calendar for this non profit organization.
	 */
	private void addNewAuction() {
		Date date;
		String startTime;
		String endTime;
		int year, month, day;

		myOut.println("Please enter the date for the new auction.");
		myOut.println("Enter year: ");
		year = myIn.nextInt();
		myOut.println("Enter month: ");
		month = myIn.nextInt()-1;
		myOut.println("Enter day: ");
		day = myIn.nextInt();
		date = new GregorianCalendar(year, month, day).getTime();
		myOut.println("Please enter the start time (ect. 1pm)");
		startTime = myIn.next();
		myOut.println("Please enter the end time (ect. 1pm)");
		endTime = myIn.next();

		Auction auc = new Auction(myOrganizationName, date, startTime, endTime);

		myCalendar.addAuction(auc);
		currentAuction = auc;

		myOut.println("You have successfully added a new acution.\n");
		viewCurrentAuction();
	}


	private void viewCurrentAuction(){
		myOut.println("Current auction details:");
		myOut.println("Auction name: " + currentAuction.getName());
		myOut.println("Auction date: " + currentAuction.getMyDate());
		myOut.println("Auction start time: " + currentAuction.getMyStartTime());
		myOut.println("Auction end time: " + currentAuction.getMyEndTime());

		String input;
		boolean back = false;
		while(!back){
			myOut.println("Please enter a command:\n0: go back.\n1: edit auction infomation.\n2: add new item.\n3: view current items");
			input = myIn.next();
			if(input.equals("0")){	
				back = true;
			}else if(input.equals("1")){
				editAuction();
			}else if(input.equals("2")){
				addNewItem();
			}else if(input.equals("3")){
				viewItems();
			}else{
				myOut.println("Invalid input");
			}
		}



	}

	/**
	 * Edits a currently existing auction.
	 */

	private void editAuction() {
		String input;
		boolean back = false;
		while(!back){
			myOut.println("Please enter a command:\n0: go back.\n1: edit auction date.\n"
					+ "2: edit auction start time.\n3: edit auction endtime");
			input = myIn.next();
			if(input.equals("0")){	
				back = true;
			}else if(input.equals("1")){
				int year, month, day;
				Date newDate;
				myOut.println("Please enter new date.");
				myOut.println("Enter year: ");
				year = myIn.nextInt();
				myOut.println("Enter month: ");
				month = myIn.nextInt()-1;
				myOut.println("Enter day: ");
				day = myIn.nextInt();
				newDate = new GregorianCalendar(year, month, day).getTime();
				currentAuction.setMyDate(newDate);
				myOut.println("edit date successful.");
				break;
			}else if(input.equals("2")){
				myOut.println("Please enter new start time (ect. 1pm).");
				currentAuction.setMyStartTime(myIn.next());
				myOut.println("edit start time successful.");
				break;
			}else if(input.equals("3")){
				myOut.println("Please enter new end time (ect. 1pm).");
				currentAuction.setMyEndTime(myIn.next());
				myOut.println("edit end time successful.");
				break;
			}else{
				myOut.println("Invalid input");
			}
		}
	}

	/**
	 * Adds an item to the current available auction for this non profit organization.
	 */
	private void addNewItem() {
		String itemName;
		String description = "";
		double min;

		myOut.println("Please enter item name");
		itemName = myIn.next();
		myOut.println("Please enter item description.");
		 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			description = br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myOut.println("Please enter item min bid");
		min = myIn.nextDouble();

		currentAuction.addItem(itemName, description, min);
		myOut.println("add item successful");
	}

	private void viewItems(){
		boolean back = false;
		String input;
		int choice = 0;
		while(!back){	//items list of the selected auction.
			myOut.println("List of items:\n");
			myOut.println(currentAuction.retrieveItemList());

			boolean validInput = false;
			while(!validInput){
				myOut.println("\nPlease enter an item ID number or 0 to go back.\n");
				input = myIn.next();
				try{
					choice = Integer.parseInt(input);
					validInput = true;
				}catch(Exception e){
					myOut.println("Invalid input");
				}
			}
			if(choice == 0){	//break while loop go back.
				back = true;
			}else {
				Items selectedItem = currentAuction.getItem(choice);
				if(selectedItem == null){
					myOut.print("Cannot find your selection, please try again.\n");
				}else{
					//sub menu, view item details and place bid.
					editItem(choice);						
				}
			}
		}
	}
	
	/**
	 * Edits a currently existing item.
	 */
	private void editItem(int itemID) {
		String input;
		boolean back = false;
		while(!back){
			myOut.println("Please enter a command:\n0: go back.\n1: edit item name.\n"
					+ "2: edit item description.\n3: edit item min bid");
			input = myIn.next();
			if(input.equals("0")){	
				back = true;
			}else if(input.equals("1")){
				myOut.println("Please enter new item name.");
				currentAuction.getItem(itemID).setMyName(myIn.next());
				myOut.println("edit item name successfull");
				break;
			}else if(input.equals("2")){
				myOut.println("Please enter new item description.");
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				String  newdes = "";
				try {
					newdes = br.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
				currentAuction.getItem(itemID).setMyDescription(newdes);
				myOut.println("edit description successful");
				break;
			}else if(input.equals("3")){
				myOut.println("Please enter new min bid value.");
				currentAuction.getItem(itemID).setMinBid(myIn.nextDouble());
				myOut.println("edit min bid success");
				break;
			}else{
				myOut.println("Invalid input");
			}
		}
	}
}